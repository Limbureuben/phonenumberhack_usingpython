import phonenumbers # type: ignore
from phonenumbers import geocoder # type: ignore
phone_number1 = phonenumbers.parse("+256759114553")
phone_number2 = phonenumbers.parse("+254658907176")
phone_number3 = phonenumbers.parse("+254683735412")

print("\nPhone Numbers Region\n")
print(geocoder.description_for_number(phone_number1, "en"));
print(geocoder.description_for_number(phone_number2, "en"));
print(geocoder.description_for_number(phone_number3, "en"));
